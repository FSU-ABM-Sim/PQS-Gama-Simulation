/**
* Name: bdi-base-program
* Author: dario
* Tags: bdi, rnd generated values, probabilictic decision making
*/


model bdi_base_rnd

/* Insert your model definition here */

global {
	/*
	 * Generated couple of shapefiles which include for the testing purpose random assigned dots, 
	 * the amount is noted behind the file assignment and maximum that amount of agents can be assigned for that shapefile
	 * Agents will be placed on these dots so that they each have a unique position
	 * Can later be replaced with a graph if needed.
	 * 
	 */
	
	file shapefile_dot <- file("../includes/35_dots/35_dots.shp");					// 35
	//file shapefile_dot <- file("../includes/7_dot.shp.shp"); 							// 7 agents
	//file shapefile_dot <- file("../includes/10-Points/entities.shp"); 					// 10 agents	
	//file shapefile_dot <- file("../includes/11-Points/entities.shp"); 				// 11 agents
	//file shapefile_dot <- file("../includes/13-Points/entities.shp"); 				// 13 agents
	//file shapefile_dot <- file("../includes/35-Points/entities.shp"); 				// 35 agents
	//file shapefile_dot <- file("../includes/100-Points/entities.shp"); 				// 100 agents

    int organisations <- 25;															// amount of agents used for the simulation
    int nb_enterprise <- 5;																// black
    int nb_enterprise_medium <- 8;															// blue
    int nb_business_small <- 8;															// green
    int nb_startup_it <- 4;																		// red
    
    list save_adopt <- ["\n", 0, 0, "\n"]; 												// List for exporting a .csf when each agent changed their status to PQS
    int plot_data <- 0;																	//
    float sum_outdegree <- -0.000000000000001;											// social link sum of all outdegree values
    float degree_of_market_pressure <- 0.00001;
    int finished_adopting <- 0;
    
    list agents_location;																// on what point the agent is assigned
  
  

    list<int> adopting_status;
    list<int> adopting_status_enterprise;
    list<int> adopting_status_enterprise_medium;    
    list<int> adopting_status_business_small;
    list<int> adopting_status_startup_it;
            																			// list of agents that switched to PQS
    int adopt_status <- sum(adopting_status);
    int adopt_status_enterprise <- sum(adopting_status_enterprise);											// number of agents that switched to PQS
    int adopt_status_enterprise_medium <- sum(adopting_status_enterprise_medium);	
    int adopt_status_business_small <- sum(adopting_status_business_small);	
    int adopt_status_startup_it <- sum(adopting_status_startup_it);	
           
    market the_market;																	// needed to calculate the market pressure
    geometry shape <- envelope(shapefile_dot);


	/*
	 * all intentions available to the agent
	 */
	 
    predicate overcome_inertia <- new_predicate("overcome inertia");
    predicate adopt <- new_predicate("adopting new PQS-Encryption");
    predicate idle <- new_predicate("will not be adopting new PQS-Encryption");
    predicate check_improvements <- new_predicate("improving probability of adoption");
    predicate improve_know <- new_predicate("improving internal knowledge");
    predicate improve_man <- new_predicate("improving management");
    predicate improve_emp <- new_predicate("improving employes");
    
    init {
    	/*
    	 * a seed can be assigned to reproduce the exact same rnd value assignment
    	 * useful for testing and verifying of functionality
    	 * (some testing seeds include: 123756410.0 || 1997451170.0 )	
    	 */
   		// seed<- 1997451170.0;		
   		
		create dot from: shapefile_dot;
        create market {
            the_market <- self;    
        }
        
		/*
		 * creating all agents
		 * number of agents depends on the number declared. 
		 * if no specific type of agent is declared or the total of specific agents < the maximum declared amount, random default agents will be created 
		 * agents will be placed on any location from the shapefile that is still free 
		 * 
		 */
		 
        create enterprise number: nb_enterprise {
        	
        	point position <- any_location_in(one_of(dot));    	        	
			bool position_empty <- true;
       	
        	if agents_location contains position{
        		loop while: position_empty = true {
        			point position_loop <- any_location_in(one_of(dot));
        			if agents_location contains position_loop{ 
	        		}
    	    		else { 
        				location <- position_loop;
        				position_empty <- false;
        				agents_location <- agents_location + position_loop; 
     				}
     			}
        	}
        	else { 
        		location <- position;
        		agents_location <- agents_location + position; 
     		}
     		
    	}
        create enterprise_medium number: nb_enterprise_medium {
        	
        	point position <- any_location_in(one_of(dot));    	        	
			bool position_empty <- true;
       	
        	if agents_location contains position{
        		loop while: position_empty = true {
        			point position_loop <- any_location_in(one_of(dot));
        			if agents_location contains position_loop{ 
	        		}
    	    		else { 
        				location <- position_loop;
        				position_empty <- false;
        				agents_location <- agents_location + position_loop; 
     				}
     			}
        	}
        	else { 
        		location <- position;
        		agents_location <- agents_location + position; 
     		}
     		
    	}
         create business_small number: nb_business_small {
        	
        	point position <- any_location_in(one_of(dot));    	        	
			bool position_empty <- true;
       	
        	if agents_location contains position{
        		loop while: position_empty = true {
        			point position_loop <- any_location_in(one_of(dot));
        			if agents_location contains position_loop{ 
	        		}
    	    		else { 
        				location <- position_loop;
        				position_empty <- false;
        				agents_location <- agents_location + position_loop; 
     				}
     			}
        	}
        	else { 
        		location <- position;
        		agents_location <- agents_location + position; 
     		}
     		
    	}   		
          create startup_it number: nb_startup_it {
        	
        	point position <- any_location_in(one_of(dot));    	        	
			bool position_empty <- true;
       	
        	if agents_location contains position{
        		loop while: position_empty = true {
        			point position_loop <- any_location_in(one_of(dot));
        			if agents_location contains position_loop{ 
	        		}
    	    		else { 
        				location <- position_loop;
        				position_empty <- false;
        				agents_location <- agents_location + position_loop; 
     				}
     			}
        	}
        	else { 
        		location <- position;
        		agents_location <- agents_location + position; 
     		}
     		
    	}
        create org number: organisations - (nb_enterprise+nb_enterprise_medium+nb_business_small+nb_startup_it) {
        	
        	point position <- any_location_in(one_of(dot));    	        	
			bool position_empty <- true;
       	
        	if agents_location contains position{
        		loop while: position_empty = true {
        			point position_loop <- any_location_in(one_of(dot));
        			if agents_location contains position_loop{ 
	        		}
    	    		else { 
        				location <- position_loop;
        				position_empty <- false;
        				agents_location <- agents_location + position_loop; 
     				}
     			}
        	}
        	else { 
        		location <- position;
        		agents_location <- agents_location + position; 
     		}
     		
    	}
    	
    		
    	
    	
    }
    /*
     * creating the social link similar to a graph
     * each agent is considered a vertex with a outdegree that can be specified 
     * outdegree depends on the type of agent:
     * 		enterprise = maximum outdegree = number of total agents decflared in (organisations)
     * 		enterprise medium = maximum outdegree = half the number of total agents
     * 		small business = maximum outdegree = 1/4th the number of total agents
     * 		startup = maximum outdegree = 1/3rd the number of total agents
     * 
     * a display will be created with the links between agents and based on their specific color
     * 		enterprise = black
     * 		enterprise medium = blue
     * 		small business = green
     * 		startup = red  
     */
    
    reflex display_social_links{        
        loop tempOrg over: enterprise+enterprise_medium+business_small+startup_it+org{       	        	        	
			if tempOrg.type_org = 1 {					      	
                loop tempDestination over: tempOrg.social_link_base{
                    if (tempDestination !=nil){
                        bool exists<-false;
                        int max_outdegree_of_vertex <- rnd(organisations) ;
                   		int some_degree <- rnd(organisations);
                        loop tempLink over: socialLinkRepresentation{
                            if((tempLink.origin=tempOrg) and (tempLink.destination=tempDestination.agent)){
                                exists<-true;
                            }
                        }
                        if(not exists){
                            create socialLinkRepresentation number: 1{
                                origin <- tempOrg;
                                destination <- tempDestination.agent;
                                if(get_liking(tempDestination)>0 and ( some_degree < max_outdegree_of_vertex)){
                                    my_color <- #black;                                    	
                                    tempOrg.outdegree <- tempOrg.outdegree +1;
                                    degree_of_market_pressure <- degree_of_market_pressure + 1;
                                } else {
                                    my_color <- rgb(rgb(0,0,0),0);
                                }
                            }
                        }
                    }
                }
            }else if tempOrg.type_org = 2 {				      	
                loop tempDestination over: tempOrg.social_link_base{
                    if (tempDestination !=nil){
                        bool exists<-false;
                        int max_outdegree_of_vertex <- rnd(organisations/2) ;
                   		int some_degree <- rnd(organisations/2);
                        loop tempLink over: socialLinkRepresentation{
                            if((tempLink.origin=tempOrg) and (tempLink.destination=tempDestination.agent)){
                                exists<-true;
                            }
                        }
                        if(not exists){
                            create socialLinkRepresentation number: 1{
                                origin <- tempOrg;
                                destination <- tempDestination.agent;
                                if(get_liking(tempDestination)>0 and ( some_degree < max_outdegree_of_vertex)){
                                    my_color <- #blue;                                    	
                                    tempOrg.outdegree <- tempOrg.outdegree +1;
                                    degree_of_market_pressure <- degree_of_market_pressure + 1;
                                } else {
                                    my_color <- rgb(rgb(0,0,0),0);
                                }
                            }
                        }
                    }
                }            	
            }else if tempOrg.type_org = 3 {					      	
                loop tempDestination over: tempOrg.social_link_base{
                    if (tempDestination !=nil){
                        bool exists<-false;
                        int max_outdegree_of_vertex <- rnd(organisations/4) ;
                   		int some_degree <- rnd(organisations/4);
                        loop tempLink over: socialLinkRepresentation{
                            if((tempLink.origin=tempOrg) and (tempLink.destination=tempDestination.agent)){
                                exists<-true;
                            }
                        }
                        if(not exists){
                            create socialLinkRepresentation number: 1{
                                origin <- tempOrg;
                                destination <- tempDestination.agent;
                                if(get_liking(tempDestination)>0 and ( some_degree < max_outdegree_of_vertex)){
                                    my_color <- #green;                                    	
                                    tempOrg.outdegree <- tempOrg.outdegree +1;
                                    degree_of_market_pressure <- degree_of_market_pressure + 1;
                                } else {
                                    my_color <- rgb(rgb(0,0,0),0);
                                }
                            }
                        }
                    }
                }            	
            }else {					      	
                loop tempDestination over: tempOrg.social_link_base{
                    if (tempDestination !=nil){
                        bool exists<-false;
                        int max_outdegree_of_vertex <- rnd(organisations/3) ;
                   		int some_degree <- rnd(organisations/3);
                        loop tempLink over: socialLinkRepresentation{
                            if((tempLink.origin=tempOrg) and (tempLink.destination=tempDestination.agent)){
                                exists<-true;
                            }
                        }
                        if(not exists){
                            create socialLinkRepresentation number: 1{
                                origin <- tempOrg;
                                destination <- tempDestination.agent;
                                if(get_liking(tempDestination)>0 and ( some_degree < max_outdegree_of_vertex)){
                                    my_color <- #red;                                    	
                                    tempOrg.outdegree <- tempOrg.outdegree +1;
                                    degree_of_market_pressure <- degree_of_market_pressure + 1;
                                } else {
                                    my_color <- rgb(rgb(0,0,0),0);
                                }
                            }
                        }
                    }
                }           	
            }
		}            
    }
	/*
	 * Option to export a csv file 
	 * currently will save a list of 
	 * how many agents have switched to PQS and the cycle when a change occured
	 * this can be adjusted and added to if needed
	 */

	reflex save_result when: true {

		if plot_data != finished_adopting {
			write "saving now ....";
			plot_data <- sum(adopting_status);
			add adopt_status to: save_adopt;
			add cycle to: save_adopt;
			add "\n" to: save_adopt;
			save (save_adopt)
				to: "results.csv";
		}
	}
	
  	/*
  	 * Simulation ends when all agents have switched to PQS
  	 * Simulation is deterministic because there is a ever increasing value ("funds") in the calculation for the probability to adopt.
  	 * Once that value gets big enough it will eclipse all other capped values and "force" the agent into a high enough probability
  	 */ 
  //	reflex end_simulation when: adopt_status + adopt_status_enterprise + adopt_status_enterprise_medium + adopt_status_business_small + adopt_status_startup_it = organisations{
    	reflex end_simulation when: finished_adopting = organisations{
        do pause;
        ask enterprise+enterprise_medium+business_small+startup_it+org {
        //	write name;
        //	write "-- stopped inertia at cycle: " + save_cycle_idle;
        //	write "-- adopted at cycle: " + save_cycle_adopt;
    	}
    }
}  
 // drawing dots for the agents
species dot {
    aspect geom {
	draw shape color: #gray;
    }
}

/*
 * 	little workaround to not deal with "get" information from each agent and saving them in multiple lists or making a matrix based on the information
 *	instead the market will look up the information itself and based on it's finding add a value to the adopting_status list
 *	the agents can then use that information for market pressure in a simplyfied way of looking at the sum of the list which is adopt_status 
 *  if needed the market can be drawn into the simulation to physically see it but since it's intented as a helping construct it's left out
 */

 
species market control:simple_bdi{
    point target;
   	float view_dist<-10000000000.0;

    perceive target: org where (each.status = 8 and each.type_org = 0) in: view_dist{
		if length (adopting_status) =  organisations - (nb_enterprise+nb_enterprise_medium+nb_business_small+nb_startup_it) {

			adopting_status <- [];
		}
		add 1 to: adopting_status;
		adopt_status <- sum(adopting_status);
    }
    perceive target: org where (each.status != 8 and each.type_org = 0) in: view_dist {
		if length (adopting_status) =  organisations - (nb_enterprise+nb_enterprise_medium+nb_business_small+nb_startup_it)  { //organisations - (nb_enterprise+nb_enterprise_medium+nb_business_small+nb_startup_it)
			adopting_status <- [];
		}
		add 0 to: adopting_status;
		adopt_status <- sum(adopting_status);
    }
    
    perceive target: enterprise where (each.status = 8 and each.type_org = 1) in: view_dist {
		if length(adopting_status_enterprise) >=  nb_enterprise {
			adopting_status_enterprise <- [];
		}
		add 1 to: adopting_status_enterprise;
		adopt_status_enterprise <- sum(adopting_status_enterprise);
    }
    perceive target: enterprise where (each.status != 8 and each.type_org = 1) in: view_dist {
		if length(adopting_status_enterprise) >=  nb_enterprise {
			adopting_status_enterprise <- [];
		}
		add 0 to: adopting_status_enterprise;
		adopt_status_enterprise <- sum(adopting_status_enterprise);
    }

    perceive target: enterprise_medium where (each.status = 8 and each.type_org = 2) in: view_dist {
		if length (adopting_status_enterprise_medium) >=  nb_enterprise_medium {

			adopting_status_enterprise_medium <- [];
		}
		add 1 to: adopting_status_enterprise_medium;
		adopt_status_enterprise_medium <- sum(adopting_status_enterprise_medium);
    }
    perceive target: enterprise_medium where (each.status != 8 and each.type_org = 2) in: view_dist {
		if length (adopting_status_enterprise_medium) >=  nb_enterprise_medium {
			adopting_status_enterprise_medium <- [];
		}
		add 0 to: adopting_status_enterprise_medium;
		adopt_status_enterprise_medium <- sum(adopting_status_enterprise_medium);
    }
  
    perceive target: business_small where (each.status = 8 and each.type_org = 3) in: view_dist {
		if length (adopting_status_business_small) >=  nb_business_small {

			adopting_status_business_small <- [];
		}
		add 1 to: adopting_status_business_small;
		adopt_status_business_small <- sum(adopting_status_business_small);
    }
    perceive target: business_small where (each.status != 8 and each.type_org = 3) in: view_dist {
		if length (adopting_status_business_small) >=  nb_business_small {
			adopting_status_business_small <- [];
		}
		add 0 to: adopting_status_business_small;
		adopt_status_business_small <- sum(adopting_status_business_small);
    }
    
      perceive target: startup_it where (each.status = 8 and each.type_org = 4) in: view_dist {
		if length (adopting_status_startup_it) >=  nb_startup_it {

			adopting_status_startup_it <- [];
		}
		add 1 to: adopting_status_startup_it;
		adopt_status_startup_it <- sum(adopting_status_startup_it);
    }
    perceive target: startup_it where (each.status != 8 and each.type_org = 4) in: view_dist {
		if length (adopting_status_startup_it) >=  nb_startup_it {
			adopting_status_startup_it <- [];
		}
		add 0 to: adopting_status_startup_it;
		adopt_status_business_small <- sum(adopting_status_startup_it);
    }    
    
    aspect default {	
    //  draw square(10) color: #black ;
    }
}

/*
 * org will be the default agent with all internal variables as discribed in the paper
 * for further simulation with specified values and different org sizes a inheritence contruct will be used 
 * children will get all functionality and values can then be individuelly specified 
 * 
 */

species org control:simple_bdi {
    
    //enables internal probabilistic choice functionality, instead of desition making based on strength values
    bool probabilistic_choice <- true;
 
 	/*
 	 * relevent adjustment values for all agents per simulation 
 	 * most of these are superimposed by the parent 
 	 * for random run -> rnd(-1.0, 1.0) / rnd(0.0, 1.0)	 can be used 
 	 */
 
 	float inertia <- 1.0;											// some Number R+
 
 	float emp;														// value assigned in parent based on organisation status
	float man; 														// value assigned in parent based on organisation status
 
 	float liking <- rnd(-1.0, 1.0); float dominance <- rnd(-1.0, 1.0); float solidarity <- rnd(0.0, 1.0); float familiarity <- rnd(0.0, 1.0); float trust <- rnd(-1.0, 1.0);
	float com <- (liking+dominance+solidarity+familiarity+trust)/5;	//social link strength
 
 	float gov_fin;													// value assigned in parent based on organisation status
  	float gov_leg; 													// value assigned in parent based on organisation status
   	float pre_cus;													// value assigned in parent based on organisation status
 	float pre_mar <- sum_outdegree/degree_of_market_pressure;  		// needs to be updated with formular in each plan it is needed  		pre_mar <- adopt_status / organisations; write "pressure market : " + pre_mar;	
  	float pressure <- pre_mar + pre_cus + gov_leg + gov_fin + com;  // total pressure and financial insentive
  
   	float in_know <- in_know + emp + man;							// initial value assigned in parent based on organisation status dependencies calculated in for each agent
   																	// combined knowledge of company and all employees
   	float in_res <- in_res+(in_res*pressure); 						// initial value assigned in parent based on organisation status dependencies calculated in for each agent, 
   																	// market pressure leads to in increase of internal ressources based on total pressure
   		
 	float cost <- cost + emp/2 + man/2;								// value assigned in parent based on organisation status
 	float ra;			 											// value assigned in parent based on organisation status 


	float funds <- (in_res + ra * int(cycle/12) + gov_fin); 		// value assigned in parent based on organisation status
  	float prob_cost <- 1/(1+exp(-2.75*(funds-cost)));	
 
  	float desire_adopt <- 0.0;					 					// (0-1)
		
	int type_org <- 0;  											// value assigned in parent based on organisation status 0: default (parent agent)  1: Enterprise 2: Medium-Enterprise 3: Small business 4: Startup with IT Background  	  
	
	
	/*
	 * programming specific variables
	 * 
	 */
									
	int last_status <- 0; 											// buffer variable to save the status of the previous cycle
	int status <- 0;												// 0 -> in Inertia -> 1 in trying to adopt 2-> adopting new encryption

	//float av <- 0.0; 												// will not be needed in a programming point of view, since gama provides an internal variable "cycle" that does exactly what is needed of av						
	
   	float last_pressure <- pressure;								// buffer variable to save the pressure value of the previous cycle
    int outdegree <- 0;												// personal outdegree will be set in social link to it's simulation value
    
    int save_cycle_idle <- 0;										// save parameters
    int save_cycle_adopt <- 0;
    
    //weights for further simulation research
	float inert_in_know<- 1.0; float inert_funds<- 1.0; float inert_pressure; 
	float d_prob_cost<- 1.0; float d_pressure <- 1.0; float d_in_know <- 1.0;    
    
    /*
     * icon imports, color assignmet 
     * all icons are copyright free and fair use downloaded from: www.flaticon.com
     */ 
     
    float view_dist<-1000000.0;
    rgb my_color<- #green; //rnd_color(255);
    image_file my_icon <- red_lock; 
    image_file green_lock <- image_file("../includes/Icons/padlock_green.png");
    image_file red_lock <- image_file("../includes/Icons/padlock_red.png");
    image_file purple_lock <- image_file("../includes/Icons/padlock_purple.png");
	image_file improvement <- image_file("../includes/Icons/improvement.png");   
	image_file improvement_know <- image_file("../includes/Icons/open-book.png");  	
	image_file improvement_man <- image_file("../includes/Icons/management.png");  	
	image_file improvement_emp <- image_file("../includes/Icons/team.png");  	
	image_file waiting <- image_file("../includes/Icons/time-left.png");  		
	 
    point target;
	
	// enables integrated social link functionality
    bool use_social_architecture <- true;
    
    /*
     * starting each simulation with the desire to get out of the inertia phase
     */
    
    init {
   	
        do add_desire(overcome_inertia);
    }
    
    /*
     * social link
     * making a connection to all other agents and coloring them for the graph
     *  
     */ 
    
    perceive target: enterprise+enterprise_medium+business_small+startup_it+org in: view_dist {
        socialize liking: 1 -  point(my_color.red, my_color.green, my_color.blue) distance_to point(myself.my_color.red, myself.my_color.green, myself.my_color.blue) / 255;
    }
    
    rule belief: adopt new_desire: adopt strength: desire_adopt;
    rule belief: idle new_desire: idle strength: 1-desire_adopt;
    
    /*
     * inertia as described will be used to simulate the ramp up process of an organisation
     * this usually includes setting aside funding, reassigning personal to a new team or however the organisation is structered
     * market pressure will be considered since seeing competition adopt new technology or starting to cater to a growing market can insite increasing willingness to start as well
     * inertia will not be growing thus if the sum would be negative nothing happens until the growing values exceed negative ones and lead to a decrease in inertia
     * once inertia is overcome the agent gets the choose how to proceed 
     */
    
    plan check_inertia intention: overcome_inertia {

			
			// update pressure and funds
			pre_mar <- sum_outdegree/degree_of_market_pressure;	
			pressure <- pre_mar + pre_cus + gov_leg + gov_fin + com;
			// remove old pressure value from in_res and add the new pressure value
			if pressure != last_pressure {
				in_res <- in_res-(in_res*last_pressure);
				last_pressure <- pressure;
				in_res <- in_res+(in_res*pressure); 					
			}
			funds <- (in_res + ra * int(cycle/12) + gov_fin);
					
			// update probabilities

      	 	prob_cost <- 1/(1+exp(-2.75*(funds-cost)));
      	 	desire_adopt <- 1/(1+exp(-(d_prob_cost*prob_cost + d_pressure*pressure + d_in_know*in_know -1.5)));
      	 	 			
 			if (inert_in_know*in_know + inert_funds*funds + inert_pressure*pressure) > 0  {  
      			inertia <- inertia - (inert_in_know*in_know + inert_funds*funds + inert_pressure*pressure);      			
      		}
      		if inertia <= 0 {
      			do remove_intention(overcome_inertia, true);
      			do remove_desire(overcome_inertia);
      			do add_desire(predicate:adopt, strength: desire_adopt);
    		  	do add_desire(predicate:check_improvements, strength: 1-desire_adopt);
				do add_desire(predicate:idle, strength: 1-desire_adopt);
				my_color <- #blue;
				save_cycle_idle <- cycle +1;
      		}	
    } 
    
    /*
     * Once the Agents switches to PQS 
     * all graphical values will be adjusted
     * the outdegree of all finished agents will be increased by the agents outdegree, this will increase the market pressure by the weight that the agent has on the market
     * the cycle when the agent switched will be saved in cycle + 1 because cycle starts at 0
     * 
     */
    
    plan adopting intention: adopt {
			my_icon <- green_lock;
       		my_color <- #red;
       		status <- 8;
       		if last_status != status {
       			last_status <- status;
       			sum_outdegree <- sum_outdegree + outdegree; 
     			save_cycle_adopt <- cycle +1;
     			finished_adopting <- finished_adopting +1;
       		}

       } 
    /*
     * Idling will first check if the agent has done an improvement earlier, if yes the agent as to wait for 2 cycles 
     * it then updates the growing valus market pressure, funds, cost, and desire to adopt
     * based on the new desire to adopt the agent will choose how to continue based on the available plans
     * 
     */  
       
    plan idling intention: idle {
			if status > 3 {
				status <- status -1;
				my_icon <- waiting;	
			}else {    	
	 			my_icon <- purple_lock;
       			status <- 1;
  				
				// update pressure and funds
				pre_mar <- sum_outdegree/degree_of_market_pressure;	
				pressure <- pre_mar + pre_cus + gov_leg + gov_fin + com;
				// remove old pressure value from in_res and add the new pressure value
				if pressure != last_pressure {
					in_res <- in_res-(in_res*last_pressure);
					last_pressure <- pressure;
					in_res <- in_res+(in_res*pressure); 					
				}  	
				funds <- (in_res + ra * int(cycle/12) + gov_fin);
				
				// update probabilities
      		 	prob_cost <- 1/(1+exp(-2.75*(funds-cost)));
      		 	desire_adopt <- 1/(1+exp(-(d_prob_cost*prob_cost + d_pressure*pressure + d_in_know*in_know -1.5)));

				do remove_desire(predicate:idle);
     	 		do remove_desire(predicate:adopt);
    		  	do add_desire(predicate:adopt, strength: desire_adopt);
    		  	do add_desire(predicate:check_improvements, strength: 1-desire_adopt);
				do add_desire(predicate:idle, strength: 1-desire_adopt);
			}
	}

	/*
	 * check improvement will look if there is room for improvement meaning if the costs can be increased or if they are maxed out
	 * if costs can be increased the agent will decide where to apply an improvement based on a probability
	 * all other desires get removed from the available list and only the improvements are available
	 */
    plan improve_odds intention: check_improvements {
	 		float probability_in_know <- 1 - in_know;
	 		float probability_man <- 1- man;
	 		float probability_emp <- 1- emp;
	 		my_icon <- improvement;
       		status <- 3;    		
       		if cost < 1 {
       			do remove_desire(predicate:idle);
      			do remove_desire(predicate:adopt);
      			do remove_desire(predicate:check_improvements);
    		  	do add_desire(predicate:improve_know, strength: probability_in_know);
				do add_desire(predicate:improve_man, strength: probability_man);
				do add_desire(predicate:improve_emp, strength: probability_emp);          			
       		}else{
       			do remove_desire(predicate:adopt);
      			do remove_desire(predicate:check_improvements);
    		  	do add_desire(predicate:idle, strength: 1.0);
       		}
       }
       
     /*
      * improve_know / improve_man / improve_emp
      * based on how much costs and the specific aspect can be increased the agent will adjust those values 
      * for knowledge it's a one to one increase to costs as for man and emp it's a 1 to 2 ratio
      * since there is a corralation between in_know -> man and emp and increase in either of the two will also net an increase in the internal knowledge
      * 	a collective update was considered to check if an improvement occured and model it closer to the beyes network but the increased performance of the current
      * 	implementation outweighs the closer "theoretical" approach
      */         
    plan improving_know intention: improve_know {
       		float difference_cost <- 1 - cost;
       		float difference_in_know <- 1- in_know;   
	 		my_icon <- improvement_know;
       		status <- 5;
       		if difference_cost < 0.2 and in_know < 0.2 {
       			cost <- cost + 0.4;
       			in_know <- in_know + 0.4;
       		}else if difference_cost < 0.5 and in_know < 0.5 {
       			cost <- cost + 0.2;
       			in_know <- in_know + 0.2;     			
       		}else if difference_cost < 0.75 and in_know < 0.75 {
       			cost <- cost + 0.1;
       			in_know <- in_know + 0.1;	
       		}else {
      			cost <- cost + 0.05;
       			in_know <- in_know + 0.05;
       		}
			do remove_desire(predicate:improve_know);
			do remove_desire(predicate:improve_man);
			do remove_desire(predicate:improve_emp);  
    		do add_desire(predicate:idle, strength: 1.0);
       } 
      plan improving_man intention: improve_man {
       		float difference_cost <- 1 - cost;
       		float difference_man <- 1- man;   
	 		my_icon <- improvement_man;
       		status <- 5;
       		if difference_cost < 0.2 and man < 0.2 {
       			cost <- cost + 0.2;
       			man <- man + 0.4;
       			in_know <- in_know + 0.4;
       		}else if difference_cost < 0.5 and man < 0.5 {
       			cost <- cost + 0.15;
       			man <- man + 0.3; 
       			in_know <- in_know + 0.3;    			
       		}else if difference_cost < 0.75 and man < 0.75 {
       			cost <- cost + 0.1;
       			man <- man + 0.2;
       			in_know <- in_know + 0.2;	
       		}else {
       			cost <- cost + 0.05;
       			man <- man + 0.1;
       			in_know <- in_know + 0.1;
       		}
			do remove_desire(predicate:improve_know);
			do remove_desire(predicate:improve_man);
			do remove_desire(predicate:improve_emp);  
    		do add_desire(predicate:idle, strength: 1.0);
       }  
       plan improving_emp intention: improve_emp {
       		float difference_cost <- 1 - cost;
       		float difference_emp <- 1- emp;   
	 		my_icon <- improvement_emp;
       		status <- 5;
       		if difference_cost < 0.2 and emp < 0.2 {
       			cost <- cost + 0.2;
       			emp <- emp + 0.4;
       			in_know <- in_know + 0.4;
       		}else if difference_cost < 0.5 and emp < 0.5 {
       			cost <- cost + 0.15;
       			emp <- emp + 0.3;
       			in_know <- in_know + 0.3;     			
       		}else if difference_cost < 0.75 and emp < 0.75 {
      			cost <- cost + 0.1;
       			emp <- emp + 0.2;
       			in_know <- in_know + 0.2;	
       		}else {
       			cost <- cost + 0.05;
       			emp <- emp + 0.1;
       			in_know <- in_know + 0.1;
       		}
			do remove_desire(predicate:improve_know);
			do remove_desire(predicate:improve_man);
			do remove_desire(predicate:improve_emp);  
    		do add_desire(predicate:idle, strength: 1.0);
       }  
   
  
  
	/*
	 * formatting of the output
	 * the desire_adopt will be at the same location as the icon but 1 layer higher so it's visible on top of the icon
	 */  
    aspect default {
		draw my_icon size: 400;    	
     	//draw string(outdegree with_precision 2) depth: 1 size: 10050 border: #black color: #black; //desire_adopt
     	draw string(desire_adopt with_precision 2) depth: 1 font:font("Helvetica", 30) rotate: 0  border: #black color: #black; //desire_adopt
    }
}


/*
 * species enterprise parent: org {
 * species medium-sized-enterprise parent: org {
 * species small-business parent: org {
 * species it-startup parent: org {
 * 
 */
species enterprise parent: org {
	int type_org <- 1;

	float emp <- 0.2;											
	float man <- 0.2; 											

 	float gov_fin <- 0.0;										
  	float gov_leg <- 0.0; 										
   	float pre_cus<- 0.0;										
   
   	float in_know <- 0.2 + emp + man; 										// the initial value will only be knowledge of the company and later combined with human knowledge
	float in_res <- 0.3;										
   	
   	float cost <- 0.2 + emp/2 + man/2;												
	float funds <- 0.2;  										
	float ra <- 0.05;    										// R    {Adjustment weight to the yearly increase of available internal resources. A higher number implies the company is willing to set aside more money for the process of adoption.

    image_file green_lock <- image_file("../includes/Icons/enter_green_lock.png");
    image_file red_lock <- image_file("../includes/Icons/enter_red_lock.png");
    image_file purple_lock <- image_file("../includes/Icons/enter_purple_lock.png");
	image_file improvement <- image_file("../includes/Icons/enter_improv.png");   
	image_file improvement_know <- image_file("../includes/Icons/enter_know.png");  	
	image_file improvement_man <- image_file("../includes/Icons/enter_man.png");  	
	image_file improvement_emp <- image_file("../includes/Icons/enter_emp.png");  	
	image_file waiting <- image_file("../includes/Icons/enter_waiting.png");  	
	image_file my_icon <- red_lock; 
}
species enterprise_medium parent: org {
	int type_org <- 2;	

	float emp <- 0.05;										
	float man <- 0.05; 											

 	float gov_fin <- 0.0;										
  	float gov_leg <- 0.0; 										 
   	float pre_cus<- 0.0;										
   
   	float in_know <- 0.15; 										// the initial value will only be knowledge of the company and later combined with human knowledge
	float in_res <- 0.2;									
   	
   	float cost <- 0.25;										
	float funds <- 0.1;  									
	float ra <- 0.03;    										// R    {Adjustment weight to the yearly increase of available internal resources. A higher number implies the company is willing to set aside more money for the process of adoption.


	
	image_file green_lock <- image_file("../includes/Icons/middle_green_lock.png");
    image_file red_lock <- image_file("../includes/Icons/middle_red_lock.png");
    image_file purple_lock <- image_file("../includes/Icons/middle_purple_lock.png");
	image_file improvement <- image_file("../includes/Icons/middle_improv.png");   
	image_file improvement_know <- image_file("../includes/Icons/middle_know.png");  	
	image_file improvement_man <- image_file("../includes/Icons/middle_man.png");  	
	image_file improvement_emp <- image_file("../includes/Icons/middle_emp.png");  	
	image_file waiting <- image_file("../includes/Icons/middle_waiting.png");  	
	image_file my_icon <- red_lock; 	
}
species business_small parent: org {
	int type_org <- 3;
	
	float emp <- -0.5;											
	float man <- -0.25; 											

 	float gov_fin <- 0.0;										
  	float gov_leg <- 0.0; 										
   	float pre_cus<- 0.0;									
   
   	float in_know <- 0.05; 										// the initial value will only be knowledge of the company and later combined with human knowledge
	float in_res <- 0.05;										
   	
   	float cost <- 0.3;											
	float funds <- 0.01;  										 
	float ra <- 0.02;    										// R    {Adjustment weight to the yearly increase of available internal resources. A higher number implies the company is willing to set aside more money for the process of adoption.
	
	
	
	image_file green_lock <- image_file("../includes/Icons/small_green_lock.png");
    image_file red_lock <- image_file("../includes/Icons/small_red_lock.png");
    image_file purple_lock <- image_file("../includes/Icons/small_purple_lock.png");
	image_file improvement <- image_file("../includes/Icons/small_improv.png");   
	image_file improvement_know <- image_file("../includes/Icons/small_know.png");  	
	image_file improvement_man <- image_file("../includes/Icons/small_man.png");  	
	image_file improvement_emp <- image_file("../includes/Icons/small_emp.png");  	
	image_file waiting <- image_file("../includes/Icons/small_waiting.png");  	
	image_file my_icon <- red_lock; 	
}
species startup_it parent: org {
	int type_org <- 4;
	
	float emp <- 0.2;											
	float man <- 0.05; 											

 	float gov_fin <- 0.0;									
  	float gov_leg <- 0.0; 										
   	float pre_cus<- 0.0;									
   
   	float in_know <- 0.0; 										// the initial value will only be knowledge of the company and later combined with human knowledge
	float in_res <- 0.2;										
   	
   	float cost <- 0.3;										
	float funds <- 0.05;  										 
	float ra <- 0.05;    										// R    {Adjustment weight to the yearly increase of available internal resources. A higher number implies the company is willing to set aside more money for the process of adoption.
	
	
	
	image_file green_lock <- image_file("../includes/Icons/start_green_lock.png");
    image_file red_lock <- image_file("../includes/Icons/start_red_lock.png");
    image_file purple_lock <- image_file("../includes/Icons/start_purple_lock.png");
	image_file improvement <- image_file("../includes/Icons/start_improv.png");   
	image_file improvement_know <- image_file("../includes/Icons/start_know.png");  	
	image_file improvement_man <- image_file("../includes/Icons/start_man.png");  	
	image_file improvement_emp <- image_file("../includes/Icons/start_emp.png");  	
	image_file waiting <- image_file("../includes/Icons/start_waiting.png");  	
	image_file my_icon <- red_lock; 	
}


species socialLinkRepresentation{
    org origin;
    agent destination;
    rgb my_color;
    
    aspect base{
        draw line([origin,destination],50.0) color: my_color end_arrow:10;
    }
}

experiment Agent_Model type: gui {
    output {
        display map type: opengl {
            species market ;
            species org;
            species enterprise;
            species enterprise_medium;
            species business_small;
            species startup_it;
        }

        display socialLinks type: opengl{
        species socialLinkRepresentation aspect: base;
    }
		/*
		 * output chart with the sum of all agents that switched to PQS
		 */
        display chart {
            chart "Adopted" type: series {
       			// datalist legend: org accumulate each.name value: org accumulate each.status color: org accumulate each.my_color;
   				// data "#Agents on PQS" value: adopt_status+adopt_status_enterprise color: #black; 
   				data "#Agents on PQS" value: finished_adopting color: #black;       			
            }
        }
    }


}